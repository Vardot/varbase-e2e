Varbase E2E sample archive.
It holds two reports.
